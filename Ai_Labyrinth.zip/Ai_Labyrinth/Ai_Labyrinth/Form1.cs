﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace LabyrinthGame
{
    public partial class Form1 : Form
    {
        private LabyrinthLogic labyrinth;
        private List<(int, int)> currentPath;
        private readonly int cellSize = 50;
        private readonly int rows = 10;
        private readonly int cols = 10;
        private readonly string[] algorithms = { "Simple Trial-Error", "Trial-Error Restart", "Backtrack", "Depth-First", "Breadth-First", "A*" };
        private int currentAlgorithmIndex = 0;
        private Label lblStatus;

        public Form1()
        {
            InitializeComponent();
            labyrinth = new LabyrinthLogic();
            currentPath = null;
            this.ClientSize = new Size(cols * cellSize, rows * cellSize + 110); // Increased height for labels and status

            // Add toggle button to cycle through algorithms
            var btnToggle = new Button { Text = "Toggle Algorithm: " + algorithms[currentAlgorithmIndex], Location = new Point(10, rows * cellSize + 10), Width = 200 };
            btnToggle.Click += (s, e) =>
            {
                // Cycle to the next algorithm
                currentAlgorithmIndex = (currentAlgorithmIndex + 1) % algorithms.Length;
                btnToggle.Text = "Toggle Algorithm: " + algorithms[currentAlgorithmIndex];

                // Run the selected algorithm
                switch (algorithms[currentAlgorithmIndex])
                {
                    case "Simple Trial-Error":
                        currentPath = labyrinth.SimpleTrialError();
                        break;
                    case "Trial-Error Restart":
                        currentPath = labyrinth.TrialErrorWithRestart(25);
                        break;
                    case "Backtrack":
                        currentPath = labyrinth.Backtrack(30);
                        break;
                    case "Depth-First":
                        currentPath = labyrinth.DepthFirst();
                        break;
                    case "Breadth-First":
                        currentPath = labyrinth.BreadthFirst();
                        break;
                    case "A*":
                        currentPath = labyrinth.AStar();
                        break;
                }

                // Update status label
                lblStatus.Text = $"Current Algorithm: {algorithms[currentAlgorithmIndex]}" +
                                 (currentPath != null ? "\nPath found!" : "\nNo path found.");
                Invalidate();
            };

            this.Controls.Add(btnToggle);

            // Add labels for start and end points
            var lblStart = new Label { Text = "Start (0,0)", Location = new Point(10, rows * cellSize + 40), AutoSize = true };
            var lblEnd = new Label { Text = "End (9,9)", Location = new Point(100, rows * cellSize + 40), AutoSize = true };
            this.Controls.Add(lblStart);
            this.Controls.Add(lblEnd);

            // Add status label
            lblStatus = new Label { Text = "Current Algorithm: " + algorithms[currentAlgorithmIndex], Location = new Point(10, rows * cellSize + 70), AutoSize = true };
            this.Controls.Add(lblStatus);

            // Run the first algorithm on startup
            currentPath = labyrinth.SimpleTrialError();
            lblStatus.Text = $"Current Algorithm: {algorithms[currentAlgorithmIndex]}" +
                             (currentPath != null ? "\nPath found!" : "\nNo path found.");
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;

            // Draw the labyrinth
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    int x = col * cellSize;
                    int y = row * cellSize;
                    if (labyrinth.Grid[row, col] == 1)
                        g.FillRectangle(Brushes.Black, x, y, cellSize, cellSize);
                    else if ((row, col) == labyrinth.Start)
                    {
                        g.FillRectangle(Brushes.Green, x, y, cellSize, cellSize);
                        g.DrawString("S", new Font("Arial", 12), Brushes.White, x + cellSize / 4, y + cellSize / 4);
                    }
                    else if ((row, col) == labyrinth.End)
                    {
                        g.FillRectangle(Brushes.Red, x, y, cellSize, cellSize);
                        g.DrawString("E", new Font("Arial", 12), Brushes.White, x + cellSize / 4, y + cellSize / 4);
                    }
                    else
                        g.FillRectangle(Brushes.White, x, y, cellSize, cellSize);
                    g.DrawRectangle(Pens.Black, x, y, cellSize, cellSize);
                }
            }

            // Draw the path in blue
            if (currentPath != null)
            {
                for (int i = 0; i < currentPath.Count - 1; i++)
                {
                    int x1 = currentPath[i].Item2 * cellSize + cellSize / 2;
                    int y1 = currentPath[i].Item1 * cellSize + cellSize / 2;
                    int x2 = currentPath[i + 1].Item2 * cellSize + cellSize / 2;
                    int y2 = currentPath[i + 1].Item1 * cellSize + cellSize / 2;
                    g.DrawLine(new Pen(Color.Blue, 3), x1, y1, x2, y2);
                }
            }
        }
    }
}
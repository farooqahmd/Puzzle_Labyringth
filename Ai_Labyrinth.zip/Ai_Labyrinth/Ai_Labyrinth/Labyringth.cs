﻿using System;
using System.Collections.Generic;

public class LabyrinthLogic
{
    public int[,] Grid { get; private set; }
    public int Rows { get; private set; }
    public int Cols { get; private set; }
    public (int, int) Start { get; private set; }
    public (int, int) End { get; private set; }
    private readonly int[] rowDirections = { -1, 1, 0, 0 }; // Up, Down, Left, Right
    private readonly int[] colDirections = { 0, 0, -1, 1 };

    public LabyrinthLogic()
    {
        Rows = 10;
        Cols = 10;
        Grid = new int[, ]
        {
            { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 },
            { 0, 0, 1, 1, 0, 0, 0, 0, 1, 1 },
            { 1, 0, 0, 1, 1, 1, 1, 0, 0, 1 },
            { 1, 1, 0, 0, 0, 0, 1, 1, 0, 1 },
            { 1, 1, 1, 1, 1, 0, 0, 1, 0, 1 },
            { 1, 0, 0, 0, 1, 1, 0, 1, 0, 1 },
            { 1, 0, 1, 0, 0, 0, 0, 1, 0, 1 },
            { 1, 0, 1, 1, 1, 1, 1, 1, 0, 0 },
            { 1, 0, 0, 0, 0, 0, 0, 0, 1, 0 },
            { 1, 1, 1, 1, 1, 1, 1, 0, 0, 2 }
        };
        Start = (0, 0);
        End = (9, 9);
    }

    public bool IsValidMove(int row, int col)
    {
        return row >= 0 && row < Rows && col >= 0 && col < Cols && Grid[row, col] != 1;
    }

    // Simple Trial-Error Method
    public List<(int, int)> SimpleTrialError()
    {
        var path = new List<(int, int)>();
        var visited = new bool[Rows, Cols];
        path.Add(Start);
        visited[Start.Item1, Start.Item2] = true;

        while (path.Count > 0)
        {
            var current = path[path.Count - 1];
            if (current == End) return path;

            bool moved = false;
            for (int i = 0; i < 4; i++)
            {
                int newRow = current.Item1 + rowDirections[i];
                int newCol = current.Item2 + colDirections[i];
                if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
                {
                    path.Add((newRow, newCol));
                    visited[newRow, newCol] = true;
                    moved = true;
                    break;
                }
            }
            if (!moved) path.RemoveAt(path.Count - 1);
        }
        return null;
    }

    // Trial-Error with Restart and Depth-Bound
    public List<(int, int)> TrialErrorWithRestart(int depthBound)
    {
        int attempts = 0;
        while (attempts < 5) // Restart up to 5 times
        {
            var path = new List<(int, int)>();
            var visited = new bool[Rows, Cols];
            path.Add(Start);
            visited[Start.Item1, Start.Item2] = true;

            if (TrialErrorRecursive(path, visited, depthBound))
                return path;
            attempts++;
        }
        return null;
    }

    private bool TrialErrorRecursive(List<(int, int)> path, bool[,] visited, int depthBound)
    {
        if (path.Count > depthBound) return false;
        var current = path[path.Count - 1];
        if (current == End) return true;

        for (int i = 0; i < 4; i++)
        {
            int newRow = current.Item1 + rowDirections[i];
            int newCol = current.Item2 + colDirections[i];
            if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
            {
                path.Add((newRow, newCol));
                visited[newRow, newCol] = true;
                if (TrialErrorRecursive(path, visited, depthBound))
                    return true;
                path.RemoveAt(path.Count - 1);
                visited[newRow, newCol] = false;
            }
        }
        return false;
    }

    // Backtrack with Parameters (e.g., max steps)
    public List<(int, int)> Backtrack(int maxSteps)
    {
        var path = new List<(int, int)>();
        var visited = new bool[Rows, Cols];
        path.Add(Start);
        visited[Start.Item1, Start.Item2] = true;

        if (BacktrackRecursive(path, visited, maxSteps))
            return path;
        return null;
    }

    private bool BacktrackRecursive(List<(int, int)> path, bool[,] visited, int maxSteps)
    {
        if (path.Count > maxSteps) return false;
        var current = path[path.Count - 1];
        if (current == End) return true;

        for (int i = 0; i < 4; i++)
        {
            int newRow = current.Item1 + rowDirections[i];
            int newCol = current.Item2 + colDirections[i];
            if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
            {
                path.Add((newRow, newCol));
                visited[newRow, newCol] = true;
                if (BacktrackRecursive(path, visited, maxSteps))
                    return true;
                path.RemoveAt(path.Count - 1);
                visited[newRow, newCol] = false;
            }
        }
        return false;
    }

    // Depth-First Search
    public List<(int, int)> DepthFirst()
    {
        var path = new List<(int, int)>();
        var visited = new bool[Rows, Cols];
        path.Add(Start);
        visited[Start.Item1, Start.Item2] = true;

        if (DepthFirstRecursive(path, visited))
            return path;
        return null;
    }

    private bool DepthFirstRecursive(List<(int, int)> path, bool[,] visited)
    {
        var current = path[path.Count - 1];
        if (current == End) return true;

        for (int i = 0; i < 4; i++)
        {
            int newRow = current.Item1 + rowDirections[i];
            int newCol = current.Item2 + colDirections[i];
            if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
            {
                path.Add((newRow, newCol));
                visited[newRow, newCol] = true;
                if (DepthFirstRecursive(path, visited))
                    return true;
                path.RemoveAt(path.Count - 1);
                visited[newRow, newCol] = false;
            }
        }
        return false;
    }

    // Breadth-First Search (Guarantees Shortest Path)
    public List<(int, int)> BreadthFirst()
    {
        var queue = new Queue<List<(int, int)>>();
        var visited = new bool[Rows, Cols];
        var initialPath = new List<(int, int)> { Start };
        queue.Enqueue(initialPath);
        visited[Start.Item1, Start.Item2] = true;

        while (queue.Count > 0)
        {
            var path = queue.Dequeue();
            var current = path[path.Count - 1];
            if (current == End) return path;

            for (int i = 0; i < 4; i++)
            {
                int newRow = current.Item1 + rowDirections[i];
                int newCol = current.Item2 + colDirections[i];
                if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
                {
                    var newPath = new List<(int, int)>(path) { (newRow, newCol) };
                    queue.Enqueue(newPath);
                    visited[newRow, newCol] = true;
                }
            }
        }
        return null;
    }

    // A* Algorithm
    public List<(int, int)> AStar()
    {
        var openSet = new PriorityQueue<(int, int, int, List<(int, int)>)>((a, b) => a.Item3 - b.Item3);
        var visited = new bool[Rows, Cols];
        openSet.Enqueue((Start.Item1, Start.Item2, 0 + ManhattanDistance(Start, End), new List<(int, int)> { Start }));
        visited[Start.Item1, Start.Item2] = true;

        while (openSet.Count > 0)
        {
            var (row, col, _, path) = openSet.Dequeue();
            var current = (row, col);
            if (current == End) return path;

            for (int i = 0; i < 4; i++)
            {
                int newRow = row + rowDirections[i];
                int newCol = col + colDirections[i];
                if (IsValidMove(newRow, newCol) && !visited[newRow, newCol])
                {
                    var newPath = new List<(int, int)>(path) { (newRow, newCol) };
                    int g = newPath.Count - 1; // Cost from start
                    int h = ManhattanDistance((newRow, newCol), End); // Heuristic
                    openSet.Enqueue((newRow, newCol, g + h, newPath));
                    visited[newRow, newCol] = true;
                }
            }
        }
        return null;
    }

    private int ManhattanDistance((int, int) a, (int, int) b)
    {
        return Math.Abs(a.Item1 - b.Item1) + Math.Abs(a.Item2 - b.Item2);
    }
}

// Simple Priority Queue for A*
public class PriorityQueue<T>
{
    private List<T> list;
    private readonly Comparison<T> comparison;

    public PriorityQueue(Comparison<T> comparison)
    {
        this.list = new List<T>();
        this.comparison = comparison;
    }

    public void Enqueue(T item)
    {
        list.Add(item);
        list.Sort(comparison);
    }

    public T Dequeue()
    {
        if (list.Count == 0) throw new InvalidOperationException("Queue is empty");
        var item = list[0];
        list.RemoveAt(0);
        return item;
    }

    public int Count => list.Count;
}